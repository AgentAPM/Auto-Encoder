﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auto_encoder_data_generator
{
    class Program
    {
        static void Main(string[] args)
        {
            int w, h, n;
            Console.Write("Podaj długość: ");
            w = Int32.Parse(Console.ReadLine());
            Console.Write("Podaj szerokość: ");
            h = Int32.Parse(Console.ReadLine());
            Console.Write("Ile próbek wygenerować: ");
            n = Int32.Parse(Console.ReadLine());
            Generator G = new Generator(w, h, new Rectangles(w, h, 1));
            G.Generate(@"..\..\..\AutoEncoder\Samples",n);
        }
    }
}
