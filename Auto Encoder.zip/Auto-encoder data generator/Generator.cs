﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;

namespace Auto_encoder_data_generator
{
    abstract class Image
    {
        protected int W;
        protected int H;
        public abstract Bitmap Draw();
    }
    class Rectangles : Image
    {
        private int N;
        private static Random RNG;
        public Rectangles(int width, int height, int count)
        {
            W = width; H = height;
            N = count;            
            RNG = new Random();
        }
        public override Bitmap Draw()
        {
            Bitmap image = new Bitmap(W, H);
            Color white = Color.FromArgb(255, 255, 255);
            Color black = Color.FromArgb(0, 0, 0);
            int x, y;

            y = H; while (y > 0) {--y;
                x = W; while (x > 0) {--x;
                    image.SetPixel(x, y, white);
                }
            }
            for (int i = 0; i < N; i++) {       //draw N rectangles
                int A1x = RNG.Next() % W; int A1y = RNG.Next() % H;     //randomize opposite vertice of rectangle
                int A2x = A1x + RNG.Next() % (W-A1x)+1; int A2y = A1y + RNG.Next() % (H-A1y)+1;
                
                for (y = A1y; y < A2y; ++y)                             //draw the rectangle
                    for (x = A1x; x < A2x; ++x) 
                        image.SetPixel(x, y, black);
            }
            return image;
        
        }
    }
    class Generator
    {
        private int W;
        private int H;
        Image shape;
        public Generator(int width, int height, Image kind)
        {
            W = width; H = height;
            this.shape = kind;
        }
        public void Generate(string path, int count)
        {
            if (Directory.Exists(path))
                for (int i = count; i > 0; i--) {
                    shape.Draw().Save(String.Format(@"{0}\sample{1}.png", path, i));
                }
        }
    }
}
