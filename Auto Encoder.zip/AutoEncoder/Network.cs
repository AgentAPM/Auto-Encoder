﻿using zad3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace zad3
{
    abstract class Activation
    {
        public abstract double Function(double x);
        public abstract double Derivative(double x);
    }
    class Sigmoid : Activation
    {
        double a;
        public Sigmoid(double a)
        {
            this.a = a;
        }
        public override double Function(double x)
        {
            return 2 / (1 + Math.Exp(-a * x)) - 1;
        }
        public override double Derivative(double x)
        {
            double eax = Math.Exp(-a * x);
            return 2 * a * eax / ((1 + eax) * (1 + eax));
        }
    }
    class Step : Activation
    {
        double a;
        public Step(double a)
        {
            this.a = a;
        }
        public override double Function(double x)
        {
            if (x < a) return 0;
            else return 1;
        }
        public override double Derivative(double x)
        {
            return 1;
        }
    }
    class Neuron
    {
        public double value;
        public double delta;
        public Synapse[] left;      //Connections from the previous layer
        public Synapse[] right;     //Connections to the next layer
        public Neuron()
        {
            value = 0;
            this.left = null;
            this.right = null;
        }
        public virtual void Calculate(Activation function)
        {
            value = 0;
            for (int i = left.Length - 1; i >= 0; i--)
                value += left[i].strength * left[i].left.value;     //Set value to sum of entering neurons scaled by synaplse's strength
            value = function.Function(value);           //and pass it through activation function
        }
    }
    class Bias : Neuron
    {
        //Bias is a neuron that is always activated to 1 and has no connections from the left
        public Bias()
        {
            value = 1;
            this.left = new Synapse[0];
            this.right = null;
        }
        public override void Calculate(Activation function)
        {
            value = 1;
        }

    }
    class Layer
    {
        public Neuron[] neurons;
        public Layer(int size, int Lsize = -1, int Rsize = -1)
        {
            if (Rsize >= 0)
            {
                neurons = new Neuron[size + 1];
                for (int i = size - 1; i >= 0; i--) {                           //for each neuron besides bias
                    neurons[i] = new Neuron();                                  //  initialize neuron
                    if (Lsize >= 0) neurons[i].left = new Synapse[Lsize + 1];   //  and set the links
                    neurons[i].right = new Synapse[Rsize];
                }
                Bias b = new Bias();                                            //initialize the remaining neuron as bias
                b.right = new Synapse[Rsize];
                neurons[size] = b;
            } else {                                                            //If this layer is the last, don't create a bias
                neurons = new Neuron[size];
                for (int i = size - 1; i >= 0; i--) {                           //for each neuron
                    neurons[i] = new Neuron();                                  //  initialize neuron
                    if (Lsize >= 0) neurons[i].left = new Synapse[Lsize + 1];   //  and set the links
                }
            }
        }
        public void Connect(Layer next)
        {
            for (int i = this.neurons.Length - 1; i >= 0; i--)                  //for each neuron in this layer besides bias
                for (int j = this.neurons[i].right.Length - 1; j >= 0; j--) {   //  for each neuron in previous layer
                    Synapse S = new Synapse();                                  //    connect this' neuron to previous'
                    this.neurons[i].right[j] = S;
                    next.neurons[j].left[i] = S;
                    S.left = this.neurons[i];
                    S.right = next.neurons[j];
                }
        }
    }
    class Synapse
    {
        public double strength;
        public double fix;      //Notes the results of Backpropagation
        public Neuron left;
        public Neuron right;
        public Synapse()
        {
            strength = 0;
            fix = 0;
        }
    }
    class Network
    {
        Layer[] layers;
        Layer input_layer;              //shortcut to the first layer
        Layer output_layer;             //shortcut to the last layer
        Activation function;
        public int InitializationSeed;  //Holds the seed to ensure accurate save/load
        public Network(int[] layersizes, Activation function)   //Create Network from layer sizes
        {
            this.function = function;
            InitializationSeed = new Random().Next();

            int k;
            layers = new Layer[layersizes.Length];
            input_layer = new Layer(layersizes[0], -1, layersizes[1]);  //First layer has no connections to the left
            layers[0] = input_layer;
            for (k = 1; k < layersizes.Length - 1; k++) {
                layers[k] = new Layer(layersizes[k], layersizes[k - 1], layersizes[k + 1]);
                layers[k - 1].Connect(layers[k]);
            }
            output_layer = new Layer(layersizes[k], layersizes[k - 1], -1);
            layers[k] = output_layer;
            layers[k - 1].Connect(layers[k]);
            InitiateRandom();
        }
        public Network(string path, Activation function)        //Create Network from file
        {
            if (!File.Exists(path))
                throw (new Exception("File not found"));
            string[] RawData = File.ReadAllLines(path);
            uint a = 0;
            InitializationSeed = Int32.Parse(RawData[a++]);
            Random RNG = new Random(InitializationSeed);
            this.function = function;

            string[] rawlines = RawData[a++].Split(' ');
            int[] layersizes;
            layersizes = new int[rawlines.Length];
            for (int j = 0; j < rawlines.Length; j++) layersizes[j] = Int32.Parse(rawlines[j]);

            int k;
            layers = new Layer[layersizes.Length];
            input_layer = new Layer(layersizes[0], -1, layersizes[1]);
            layers[0] = input_layer;
            for (k = 1; k < layersizes.Length - 1; k++) {
                layers[k] = new Layer(layersizes[k], layersizes[k - 1], layersizes[k + 1]);
                layers[k - 1].Connect(layers[k]);
                for (int i = layers[k].neurons.Length - 1; i >= 0; i--)
                    for (int j = layers[k].neurons[i].left.Length - 1; j >= 0; j--)
                        if (a < RawData.Length)
                            layers[k].neurons[i].left[j].strength = Double.Parse(RawData[a++]);
                        else                                //if not enough values were saved, fill the rest randomly
                            layers[k].neurons[i].left[j].strength = RNG.NextDouble()*2-1;
            }
            output_layer = new Layer(layersizes[k], layersizes[k - 1], -1);
            layers[k] = output_layer;
            layers[k - 1].Connect(layers[k]);
            for (int i = layers[k].neurons.Length - 1; i >= 0; i--)
                for (int j = layers[k].neurons[i].left.Length - 1; j >= 0; j--)
                    if(a<RawData.Length)
                        layers[k].neurons[i].left[j].strength = Double.Parse(RawData[a++]);
                    else                                //if not enough values were saved, fill the rest randomly
                        layers[k].neurons[i].left[j].strength = RNG.NextDouble()*2-1;
        }
        public void SaveToFile(string path)
        {
            List<string> Data = new List<string>();
            Data.Add(InitializationSeed.ToString());                                //Save the seed
            string layersizes = (output_layer.neurons.Length).ToString();
            for (int i = layers.Length - 2; i >= 0; i--) layersizes = (layers[i].neurons.Length - 1).ToString() + " " + layersizes;
            Data.Add(layersizes);                                                   //Save the layer sizes
            for (int k = 1; k < layers.Length; k++)
                for (int i = layers[k].neurons.Length - 1; i >= 0; i--)
                    for (int j = layers[k].neurons[i].left.Length - 1; j >= 0; j--)
                        Data.Add(layers[k].neurons[i].left[j].strength.ToString()); //Save every synapse in the order they're loaded
            File.WriteAllLines(path, Data);
        }
        public void InitiateRandom()
        {
            Random RNG = new Random(InitializationSeed);
            foreach (Layer k in layers.Skip(1))
                foreach (Neuron n in k.neurons)
                    foreach (Synapse s in n.left)
                        s.strength = RNG.NextDouble() * 2 - 1;   //initiate random strength between -1 and 1 in every synapse
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < layers.Length; k++)
            {
                for (int i = 0; i < layers[k].neurons.Length; i++)
                { sb.Append(layers[k].neurons[i].value); sb.Append(" "); }
                sb.Append("\n");
            }

            return sb.ToString();
        }
        public double[] Classify(double[] input)        //Process the input through the network
        {
            int i;
            for (i = input_layer.neurons.Length - 2; i >= 0; i--)
                input_layer.neurons[i].value = input[i];    //Set the input layer

            foreach (Layer L in layers.Skip(1))
                foreach (Neuron N in L.neurons)
                    N.Calculate(function);                  //Propagate forward

            double[] output = new double[output_layer.neurons.Length];  //Set output's size to the last layer's
            for (i = output_layer.neurons.Length - 1; i >= 0; i--)
                output[i] = output_layer.neurons[i].value;              //Get the output layer

            return output;
        }
        public void BackPropagation(double rate, double[] expected)
        {
            //Output layer
            for (int i = output_layer.neurons.Length - 1; i >= 0; i--) {    //Calculate deltas in the output layer to neuron.error * f'(neuron.value)
                output_layer.neurons[i].delta = (expected[i] - output_layer.neurons[i].value) * function.Derivative(output_layer.neurons[i].value);
                foreach (Synapse S in output_layer.neurons[i].left)         //Calculate the fixes in the last band of synapses
                    S.fix += S.left.value * S.right.delta * rate;
            }
            //Hidden layers
            for (int k = layers.Length - 2; k > 0; k--) {
                foreach (Neuron N in layers[k].neurons) {
                    N.delta = 0;
                    foreach (Synapse S in N.right)
                        N.delta += S.strength * S.right.delta;
                    N.delta *= function.Derivative(N.value);        //Propagate the delta backwards
                }
                foreach (Neuron N in layers[k].neurons)             //Calculate fixes in the band of entering synapses
                    foreach (Synapse S in N.left)
                        S.fix += S.left.value * S.right.delta * rate;
            }
                                                    //New fixes are added instead of being overwritten to accomodate for average-for-training-batch learning
        }
        public void ApplyLearning(double step)      //Change strengths in every synapse according to their fix value
        {
            foreach (Layer L in layers.Skip(1))
                foreach (Neuron N in L.neurons)
                    foreach (Synapse S in N.left) {
                        S.strength = S.strength *0.95 + S.fix * step;
                        S.fix = 0;
                    }
        }
    }
}
