﻿using zad3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;

namespace zad3
{
    //  Adapted from Iris Data
    struct ImageNeuron
    {

        public static double[] LoadImage(string path)
        {
            Bitmap IMG = new Bitmap(path);
            int W = IMG.Width, H = IMG.Height;
            int x, y, i = W * H;
            double[] pixels = new double[i];
            y = H; while (y > 0)
            {
                --y;
                x = W; while (x > 0)
                {
                    --x;
                    Color X = IMG.GetPixel(x, y);
                    pixels[--i] = (double)X.GetBrightness();
                }
            }
            return pixels;
        }
        public static Bitmap SideToSide(double[] expected, double[] actual, int w, int h)
        {
            int x, y, b, d = 4;
            int wd = w + d;
            Bitmap BMP = new Bitmap(w + d + w, h);
            y = h; while (y > 0)
            {
                --y;
                x = w; while (x > 0)
                {
                    --x;
                    b = (int)(expected[y * w + x] * 255);
                    if (b < 0) b = 0; if (b > 255) b = 255;
                    BMP.SetPixel(x, y, Color.FromArgb(b, b, b));
                    b = (int)(actual[y * w + x] * 255);
                    if (b < 0) b = 0; if (b > 255) b = 255;
                    BMP.SetPixel(x + wd, y, Color.FromArgb(b, b, b));
                }
                for (x = w; x < wd; ++x)
                    BMP.SetPixel(x, y, Color.FromArgb(0, 64, 192));
            }
            return BMP;
        }
        public static double Accuracy(double[] expected, double[] actual)
        {
            double passed = 0;
            for(int i = expected.Length; i-- > 0;)
            {
                double pixelaccuracy = (expected[i] - 0.5) * (actual[i] - 0.5);
                if (pixelaccuracy >= 0) passed+=1;
            }
            return passed / expected.Length;
        }
    }

    struct sample
    {
        public double[] input;
        public double[] output;
        public sample(int insize, int outsize)          //Create empty sample
        {
            input = new double[insize];
            output = new double[outsize];
        }
        public sample(double[] input, double[] output)  //Create sample of two arrays
        {
            this.input = input;
            this.output = output;
        }
        public sample(double[] line, int insize, int outsize)   //Split an array into two
        {
            if (line.Length != insize + outsize)
                throw (new Exception("Wrong sizes"));
            this.input = new double[insize];
            this.output = new double[outsize];
            for (int j = 0; j < insize; j++) input[j] = line[j];
            for (int j = 0; j < outsize; j++) output[j] = line[insize + j];
        }
    }
}
