﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Schema;

namespace zad3
{
    class Program
    {
        const string TRAININGDATA = @"..\..\Samples";
        const string DISPLAY = @"..\..\Display";
        const string SAMPLES = @"..\..\AutoEncoder.txt";
        static Network AutoEncoder;
        static List<sample> TrainingSet;
        static List<sample> TestSet;
        static double Squared(double x) { return x * x; }
        static void TestujSieć()
        {
            double bestAcc=0, sumAcc=0; double SumLoss = 0;
            int it = 0;
            foreach (sample current in TestSet)     //Test the network
            {
                ++it;
                double[] NetGuess = AutoEncoder.Classify(current.input);       //Process a sample through the neural network 
                ImageNeuron.SideToSide(current.output, NetGuess, 24, 24).Save(String.Format(@"{0}\test{1}.png",DISPLAY,it));
                int choice = 0; int correct = 0; double choiceVal = NetGuess[0];
                double loss = Squared(NetGuess[0] - current.output[0]);
                for (int i = current.output.Length - 1; i > 0; i--)             //Neuron with the highest value is considered network's choice
                {
                    loss += Squared(NetGuess[i] - current.output[i]);       //Measure how certain the network is of the i-th answer
                    if (NetGuess[i] > choiceVal) { choiceVal = NetGuess[i]; choice = i; }
                    if (current.output[i] == 1) correct = i;                //Get the actual correct choice
                }
                double accuracy = ImageNeuron.Accuracy(current.output, NetGuess);
                SumLoss += loss;
                if (accuracy > bestAcc) bestAcc = accuracy;
                sumAcc += accuracy;
            }
            Console.WriteLine("Average accuracy: {0}  best {1}. Loss = {2}", sumAcc/TestSet.Count, bestAcc, SumLoss / TestSet.Count);
        }
        static void TrenujSieć(double learning_coeff, int epochlength, int peekevery=0)
        {
            for (int epoch = 0; epoch < epochlength; epoch++)
            {
                foreach (sample current in TrainingSet) //Train the network
                {
                    double[] NetGuess = AutoEncoder.Classify(current.input);
                    AutoEncoder.BackPropagation(learning_coeff, current.output);   //Propagate the error
                    //AutoEncoder.ApplyLearning(1.0);                              //Apply the changes after each sample
                }
                AutoEncoder.ApplyLearning(1.0 / TrainingSet.Count);                //Apply changes averaged over all Training samples
                if (peekevery > 0 && epoch % peekevery == 0)
                { 
                    TestujSieć();
                    //AutoEncoder.SaveToFile(String.Format("lastpeek{0}.txt",epoch));
                }
            }
            Console.WriteLine("---- Training ended -----");
            Console.ReadLine();
        }
        static void Wczytaj(string path = null)
        {
            if (path == null) {
                Console.Write("Podaj ścieżkę: ");
                path = Console.ReadLine();
                if (path == "")
                    path = SAMPLES;                                //If no path was entered, overwrite with the default
            }
                if (File.Exists(path))                              //To create custom network, write a file with seed in the first line and list of integers in the second (example: "7 49 35 28 14 3")
                    AutoEncoder = new Network(path, new Sigmoid(1));
                else
                    AutoEncoder = new Network(new int[] { 576, 576, 16, 576, 576 }, new Sigmoid(1));

            

            TrainingSet = new List<sample>();
            TestSet = new List<sample>();
            
            for (int i = 1; File.Exists(String.Format(@"{0}\sample{1}.png", TRAININGDATA, i)); ++i)
            {
                var vector = ImageNeuron.LoadImage(String.Format(@"{0}\sample{1}.png", TRAININGDATA, i));
                sample nowa = new sample(vector, vector);
                TrainingSet.Add(nowa);
            }
            for (int i = 1; File.Exists(String.Format(@"{0}\test{1}.png", TRAININGDATA, i)); ++i)
            {
                var vector = ImageNeuron.LoadImage(String.Format(@"{0}\test{1}.png", TRAININGDATA, i));
                sample nowa = new sample(vector, vector);
                TestSet.Add(nowa);
            }
                
        }
        static void Main()
        {


            Wczytaj(SAMPLES);

            while (true)
            {
                string path;
                Console.Clear();
                Console.WriteLine("0. Wyjdź\n1. Wczytaj sieć\n2. Zapisz sieć\n3. Testuj sieć\n4. Trenuj sieć");
                switch (Console.ReadLine())
                {
                    case "0":
                        return;

                    case "1":
                        Wczytaj();
                        break;

                    case "2":
                        Console.Write("Podaj ścieżkę: ");
                        path = Console.ReadLine();
                        if (path == "")
                            AutoEncoder.SaveToFile(SAMPLES);
                        else
                            AutoEncoder.SaveToFile(path);
                        break;

                    case "3":
                        TestujSieć();
                        Console.ReadLine();
                        break;

                    case "4":
                        int epochlength, peekevery; double learning_coeff;
                        Console.Write("Podaj wartość kroku: ");
                        try { learning_coeff = Double.Parse(Console.ReadLine().Replace('.',',')); } catch { break; }
                        Console.Write("Podaj liczbę epok: ");
                        try { epochlength = Int32.Parse(Console.ReadLine()); } catch { break; }
                        Console.Write("Co ile epok wyświetlać postęp: ");
                        try { peekevery = Int32.Parse(Console.ReadLine()); } catch { peekevery=0; }
                        
                        if(peekevery>0)
                            TrenujSieć(learning_coeff, epochlength, peekevery);
                        else
                            TrenujSieć(learning_coeff, epochlength);
                        
                        break;
                }
            }
     
        }
    }
}
